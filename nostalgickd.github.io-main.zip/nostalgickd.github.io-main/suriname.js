let sarnamie= {
//"//audio-edge-es6pf.mia.g.radiomast.io/d7e8093b-6a7e-4442-a096-37f259cb7092" : "Rapar",
//"//168.195.218.193:8000/radio1-1" : "Rapar",
"//rs.suricloud.com/radio/8050/radio.mp3" : "Trishul",
"//stream.zeno.fm/6etys88fup8uv" : "Rasonic",
"//rs.suricloud.com/radio/8030/radio.mp3" : "Sangeetmala",
//"//stream.zeno.fm/nrs4d44vzv8uv;" : "Ishara",
"//stream.zeno.fm/nqm3a44vzv8uv" : "Ishara",
"//rs.suricloud.com/radio/8120/radio.mp3" : "Ek Sitara",
"//my.ssl-stream.com/Suvidha_Radio" : "Suvidha",
"//rs.suricloud.com/radio/8000/radio.mp3" : "Shruti",
"https://amorfm_192.streampartner.nl/stream" : "Amor",
"//streaming01.x-6.nl:8000/;" : "Srinagar",
"//server-25.stream-server.nl:8348/stream" : "Sitara FM",
"//stream.akaashfm.com:8000/live" : "Akaash FM",
"//onlineradio.websoftitnepal.com/8030/stream" : "Vahon",
"//server4.ujala.nl/stream/2/listen.mp3" : "Ujala",
"//stream.sfmstreaming.nl/sunrisefm" : "Sunrise FM",
"//stream2.iqhosted.nl:8000/stream/1/" : "Sangam",
"//rs.suricloud.com/radio/8130/radio.mp3" : "Sargam",
"//hidradio.live-streams.nl/live?type=.mp3/;stream.mp3" : "HiD Radio",
"//stream.zeno.fm/kzsmp5qs9k0uv" : "Radio Sarnami",
"//stream.zeno.fm/putkar0p9k0uv" : "Bollywood Sur.",
"//stream.zeno.fm/ctmsytc6em0uv" : "Joyce The Voice",
"//stream.zeno.fm/xssh6qrf1wzuv" : "Assalaam",
"//solid48.streamupsolutions.com/proxy/radiosbs/radiosbs" : "SBS Radio",
};

let general= {
"//stream.zeno.fm/7qt8yd08qchvv" : "ABC",
//"//stream.prography.com/stream/8064" : "Apintie",
"//stream.zeno.fm/zh2rs490x68uv" : "Apintie",
"//streams.radio.co/s28bc986cd/listen" : "Radio 10",
//"//168.195.218.193:8000/radio1-3" : "RP Hot One",
//"//168.195.218.193:8000/radio2-2" : "Beat FM",
"//sccn104.serverroom.us:5600/;stream.mp3" : "SCCN Smooth",
"//rs.suricloud.com/radio/8010/radio.mp3" : "Sky - Pipel",
"https://radiostream.limfmsu.com/radio" : "LIM FM",
"//rs.suricloud.com/radio/8060/radio.mp3" : "Radio 9",
"//stream.rcast.net/67505": "Suri Lite",
//"//162.244.80.245:8006/;" : "FM Gold",
"//canopus.dribbcast.com/stream/8052/stream/1/" : "Color Radio",
//"//solid41.streamupsolutions.com/proxy/yjdqldwt?mp=/stream" : "Da Beat",
//"//streaming.shoutcast.com/we-radio?" : "WE Radio",
"//caster05.streampakket.com/proxy/9338/stream/1/" : "Tamara",
"//canopus.dribbcast.com/stream/8010" : "NIO FM",
//"//127.0.0.1:26671/listen.pls" : "Radio One",
//"//listen.shoutcast.com/k1009" : "Kankantri",
"//sonic.magicdragon.nl:7011/stream" : "Pokoe FM",
"//icecast.omroep.nl/3fm-bb-mp3" : "Radio FM 103",
"//cc3b.beheerstream.com:8192/;stream.mp3" : "Cariba FM",
"//larry.torontocast.com:1795/stream" : "Neutral",
"//stream.zeno.fm/xsdmzxyhc18uv" : "Radio 804",
"//stream.zeno.fm/5tv3n9cw008uv" : "Lime",
"//stream.zeno.fm/zduxspz4kv8uv" : "Fan Da Libi",
"//stream.zeno.fm/y3k2cb2mpchvv" : "Ollies Radio",
"//stream.zeno.fm/abb1cne92hhvv" : "DC SuriRadio"
};

let javanese= {
"//worldstreaminglive.com/proxy/apzrueeh/stream" : "Garuda",
//"//streaming.radionomy.com/LaguJawa" : "Lagu Jawa",
"//94.23.148.11:8214/stream/1/" : "Siaran Jawa",
"//s5.radio.co/s1735f3c1d/listen" : "Surja Vibes",
"//stream.zeno.fm/w6hh0rqqwy8uv" : "DjRegi",
"//betelgeuse.dribbcast.com/proxy/abhost?mp=/stream" : "Bangsa Jawa",
"//stream.zeno.fm/u3abxhenhf9uv" : "Tamanredjo Talents"
};

let sranang= {
"//stream.prography.com/stream/8062" : "SRS",
"//mediaserv30.live-streams.nl:18020/stream" : "Konmakandra",
"//canopus.dribbcast.com/stream/8052" : "Anjisa",
"//worldstreaminglive.com/proxy/koyeba/stream" : "Koyeba FM",
"//stream.prography.com/stream/8062" : "Boskopu",
//"//91.196.171.99/radiobrasa" : "Brasa",
"//stream.zenolive.com/6te6g6ubed0uv.aac" : "Radio Anda",
//"//178.63.94.130:8080/9181316.ogg" : "Positive",
"//stanvasteradio.gkstreamen.nl:8120/;" : "Stanvaste Radio",
//"//46.4.5.234:8080/9173707.ogg" : "Asosye",
"//stream.zeno.fm/q4wkxqmdqchvv" : "Asosye",
"//patmos.cdnstream.com/proxy/rifawaka/?mp=/stream" : "Fawaka",
"//clare.shoutca.st/radio/8070/radio.mp3":"MS Radio",
"//stream.zeno.fm/ysd1dvrtcv8uv" : "Ketebuna",
"//stream.zeno.fm/rnf3xu9tgs8uv" : "Boeskondee Media",
"//stream.zeno.fm/1sqwfhqwra0uv" : "Fandaaki Paanzu",
"//stream.zeno.fm/kyve9mgds18uv" : "Radio Totness",
"//stream.zeno.fm/db9pak567ehvv" : "DJBadJho",
"//stream.zeno.fm/unz726g6kfhvv" : "Maipa",
"//stream.zeno.fm/p0d98x5phs8uv" : "DoubleB 2",
"//stream.zeno.fm/ym53qqc53hhvv" : "Sam Taki",

"/resources/placeholder.mp3" : "Placeholder"
};

let christian= {
"//worldstreaminglive.com/proxy/radioshalom/stream" : "Shalom",
"//stream.zeno.fm/6nt6k3e2x68uv" : "Immanu&euml;l",
"//server.jvhost.net:8120/stream" : "Kabar Katresnan",
//"//198.7.59.204/stream.mp3?ipport=198.7.59.204_31366" : "Radio 7 Gospel",
"//cc5.beheerstream.com/proxy/exoticaradio?mp=/stream" : "Radio mArt",
"//stream.zeno.fm/kadt188ugy8uv" : "Afonsoewa",
"//stream.zeno.fm/31gfhb24kfhvv" : "Tzgospel Swahili"
};

let other= {
"//d1x0scdnoh33b7.cloudfront.net/olonradio/537b9f27/master.m3u8" : "Razo",
"//d1x0scdnoh33b7.cloudfront.net/olonradio/7fb21f1b/master.m3u8" : "Caribbean FM",
"//stream.prography.com/stream/8066" : "LPM Portugese",

"/resources/placeholder.mp3" : "Placeholder"
};


let list= [sarnamie,general,sranang,christian,javanese,other];
let liststring= "sarnamie,general,sranang,christian,javanese,other";

/*block= [0,4,5,6,8,9];
let block= "[]";
let blocklist= localStorage["_block"]|| block;
block= JSON.parse(blocklist);*/

let block= [];
