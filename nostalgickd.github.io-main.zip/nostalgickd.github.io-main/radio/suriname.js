let sarnamie= {
"http://168.195.218.193:8000/radio1-1" : "Rapar",
"http://tbn.kloud.xyz:8050/radio.mp3" : "Trishul",
"http://108.59.9.147:8136/;" : "Rasonic",
"http://sgm.kloud.xyz:8030/radio.mp3" : "Sangeetmala ",
"http://nickerie.webhop.net:8000/;?type=http&nocache=5286" : "Ishara",
//"http://eksitara.kloud.xyz:8120/radio.mp3" : "Ek Sitara",
"http://79.143.187.96:8053/live" : "Suvidha",
"http://shruti.kloud.xyz:8000/radio.mp3" : "Shruti",
"https://amorfm_192.streampartner.nl/stream" : "Amor",
"https://onlineradio.websoftitnepal.com/8030/stream/1/.mp4a.40.5" : "Vahon",
"http://stream2.ujala.nl/stream/2/listen.mp3" : "Ujala",
"http://stream.sunrisefm.nl:9600/stream" : "Sunrise",
"http://stream2.iqhosted.nl:8000/stream/1/" : "Sangam",
"https://rs.suricloud.com/radio/8130/radio.mp3" : "Sargam",
"https://hidradio.live-streams.nl/live?type=.mp3/;stream.mp3" : "HiD Radio",
"https://stream.zeno.fm/kzsmp5qs9k0uv" : "Radio Sarnami",
"https://stream.zeno.fm/putkar0p9k0uv" : "Bollywood Sur.",
"https://stream.zeno.fm/ctmsytc6em0uv" : "Joyce The Voice",
"https://stream.zeno.fm/xssh6qrf1wzuv" : "Assalaam"
};

let general= {
"http://bombelman.com:5472/;?d=" : "ABC",
"http://s6.voscast.com:8150/;stream.mp3" : "Apintie",
"http://streams.radio.co/s28bc986cd/listen" : "Radio 10",
"http://168.195.218.193:8000/radio1-3" : "RP Hot One",
"http://168.195.218.193:8000/radio2-2" : "Beat FM",
"http://sccn104.serverroom.us:5600/;stream.mp3" : "SCCN Smooth",
"http://pipel.kloud.xyz:8010/radio.mp3" : "Sky Pipel",
"http://radio9.kloud.xyz:8060/radio.mp3" : "Radio 9",
"https://surilite1.radioca.st/stream" : "Suri Lite",
//"http://162.244.80.245:8006/;" : "FM Gold",
"https://canopus.dribbcast.com/stream/8052/stream/1/" : "Color Radio",
//"https://solid41.streamupsolutions.com/proxy/yjdqldwt?mp=/stream" : "Da Beat",
//"http://streaming.shoutcast.com/we-radio?" : "WE Radio",
"http://audiostreamen.nl:8006/stream" : "Tamara",
"http://bombelman.com:3062/;" : "NIO",
//"http://127.0.0.1:26671/listen.pls" : "Radio One",
"http://192.111.140.6:8117/stream" : "Fawaka",
//"http://listen.shoutcast.com/k1009" : "Kankantri",
"https://sonic.magicdragon.nl/8024/stream" : "Pokoe FM",
"https://icecast.omroep.nl/3fm-bb-mp3" : "Radio FM 103",
"http://cc3b.beheerstream.com:8192/;stream.mp3" : "Cariba FM",
"https://larry.torontocast.com:1795/stream":"Neutral",
"https://stream.zeno.fm/xsdmzxyhc18uv" : "Radio 804",
"https://stream.zeno.fm/5tv3n9cw008uv" : "Lime Radio",
"https://stream.zeno.fm/zduxspz4kv8uv" : "Fan Da Libi"
};

let javanese= {
"http://162.244.80.245:8012/;" : "Garuda",
//"http://streaming.radionomy.com/LaguJawa" : "Lagu Jawa",
"http://94.23.148.11:8214/stream/1/" : "Sirian Jawa",
"https://s5.radio.co/s1735f3c1d/listen":"Surja Vibes",
"https://stream.zeno.fm/w6hh0rqqwy8uv" : "DjRegi",
};

let sranang= {
"http://168.195.218.193:8000/radio2-0" : "SRS",
"https://mediaserv30.live-streams.nl:18020/stream" : "Konmakandra",
"https://canopus.dribbcast.com/stream/8052" : "Anjisa",
"http://162.244.80.245:8020/stream/1/" : "Koyeba",
"http://sc.sr.net:8000/radio2-1" : "Boskopu",
//"http://91.196.171.99/radiobrasa" : "Brasa",
"https://kathy.torontocast.com:2945/stream" : "Radio Anda",
//"http://178.63.94.130:8080/9181316.ogg" : "Positive",
"http://stanvasteradio.gkstreamen.nl:8120/;stream.mp3" : "Stanvaste",
"http://46.4.5.234:8080/9173707.ogg" : "Asosye",
"https://clare.shoutca.st/radio/8070/radio.mp3":"MS Radio",
"https://stream.zeno.fm/ysd1dvrtcv8uv" : "Ketebuna",
"https://stream.zeno.fm/rnf3xu9tgs8uv" : "Boeskondee Media",
"https://stream.zeno.fm/1sqwfhqwra0uv" : "Fandaaki Paanzu",
"https://stream.zeno.fm/kyve9mgds18uv" : "Radio Totness",
};

let christian= {
"http://162.244.80.245:8014/;" : "Shalom",
"http://bombelman.com:3052/random" : "Immanu&euml;l",
"http://server.jvhost.net:8120/stream" : "Kabar Katresnan",
//"http://198.7.59.204/stream.mp3?ipport=198.7.59.204_31366" : "Radio 7 Gospel",
"http://exoticaradio.shoutcaststream.com:8380/stream" : "Radio mArt",
"https://stream.zeno.fm/kadt188ugy8uv" : "Afonsoewa",
};

let other= {
"https://olon.az.icecast.ebsd.ericsson.net/salto_razo" : "Razo",
//"http://icecast.streamone.net/YoRFHeMSYJ42" : "Caribbean FM",
"http://bombelman.com:8036/;stream.nsv" : "LPM Portuguese"
};


let list= [sarnamie,general,sranang,christian,javanese,other];

let block=[];
//block= [0,4,5,6,8,9];
