let
title= "KD Radio - Suriname",
switchradio= "bollywood.html",
//block= [0,6,7,10,11];
block= [];

let list= {
"http://168.195.218.193:8000/radio1-1":"Rapar",
"http://tbn.kloud.xyz:8050/radio.mp3":"Trishul",
"http://108.59.9.147:8136/;":"Rasonic",
"http://sgm.kloud.xyz:8030/radio.mp3":"Sangeetmala",
"http://nickerie.webhop.net:8000/;stream.nsv":"Ishara",
"http://162.244.80.245:8016/;":"Ramasha",
"http://79.143.187.96:8053/live":"Suvidha",
"http://shruti.kloud.xyz:8000/radio.mp3":"Shruti",
"https://amorfm_192.streampartner.nl/stream":"Amor",
"http://stream.akaashfm.com:8000/live?1614478133151":"Akaash",
"http://94.23.148.11:8058/;":"Vahon",
"http://stream2.ujala.nl/stream/2/listen.mp3":"Ujalah",
"http://stream.sunrisefm.nl:9600/stream":"Sunrise",
"http://stream2.iqhosted.nl:8000/stream/1/":"Sangam"
};
