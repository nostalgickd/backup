let
title= "KD Radio - Bollywood",
switchradio= "index.html",
//block= [2,3,4,5,7,8,10,12];
block= [];
         
let list= {
"http://sc-bb.1.fm:8017":"Bombay Beats",
"http://109.169.46.197:8011/stream":"Diverse FM",
"http://music2.vvradio.co.in:2802/stream2":"VV Radio",
"https://astro4.rastream.com/india?type=mp3":"India Beat",
"https://c5.radioboss.fm:18125/stream":"Manpasand",
"http://s0.desimusicmix.com:8012/;stream.mp3":"Desi Music Mix",
"https://streaming.webhostnepal.com/8020/stream":"Himal Filmy",
"http://indifun.net:7000/;stream.nsv":"Indifun",
"http://peridot.streamguys.com:7150/Mirchi":"Mirchi FM",
"http://79.120.39.202:8002/indiancinema":"Caprice",
"https://prclive1.listenon.in/":"Radio City [Talk]",
"https://funasia.streamguys1.com/live9":"Big Melodies",
"https://cp12.serverse.com/proxy/hummfm?mp=/live":"Humm FM",
"http://radio.punjabrocks.com:9998/taal":"Taal",
"http://hoth.alonhosting.com:1080/;stream.mp3":"BollyHits",
"https://s5.alhastream.com/radio/8260/radio":"Nitnut",
"https://stream.zeno.fm/a69txeenvzzuv":"SRK Online",
"https://stream.bongonet.net/proxy/rhi?mp=/stream":"RHI - Covers"
};
